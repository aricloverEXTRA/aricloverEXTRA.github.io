# VillagerQuests

VillagerQuests is a mod which adds the ability to add quests to villagers.

### Installation

VillagerQuests is a mod built for the [Fabric Loader](https://fabricmc.net/). It
requires [Fabric API](https://www.curseforge.com/minecraft/mc-mods/fabric-api)
and [Cloth Config API](https://www.curseforge.com/minecraft/mc-mods/cloth-config) to be installed separately; all other
dependencies are installed with the mod.  
Since version 1.1.0 it is depended on [ftb quests](https://www.curseforge.com/minecraft/mc-mods/ftb-quests-fabric).

### License

VillagerQuests is licensed under MIT.  
