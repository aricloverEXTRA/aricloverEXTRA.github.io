# Miner's Delight (1.21+)

This folder is for **Minecraft 1.21+** versions of Miner's Delight.