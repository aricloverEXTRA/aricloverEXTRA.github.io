![Better Archeology Logo](https://i.imgur.com/8CDT9W2.png)

[![Modrinth](https://img.shields.io/modrinth/v/zCh7omyG?style=flat&logo=modrinth&logoColor=forestgreen&label=newest%3A&labelColor=black&color=forestgreen)](https://modrinth.com/mod/better-archeology)
[![CurseForge](https://img.shields.io/curseforge/v/835687?style=flat&logo=curseforge&logoColor=orangered&label=newest%3A&labelColor=black&color=orangered)](https://www.curseforge.com/minecraft/mc-mods/better-archeology)
<br/>
Fabric Mod that enhances the boring archeology-system in 1.20
