<div align="center">
  <img src="https://cdn.modrinth.com/data/USgVjXsk/a8150331e2257d66e03e09478f17e121fcd3fdea_96.webp">
  <h1>Create: The Factory Must Grow</h1>
  <a href="https://www.curseforge.com/minecraft/mc-mods/create-industry"><picture><source srcset="https://img.shields.io/badge/CurseForge-202830?style=for-the-badge&logo=curseforge" media="(prefers-color-scheme: dark)"><img src="https://img.shields.io/badge/CurseForge-white?style=for-the-badge&logo=curseforge" alt="CurseForge"></picture></a>
  <a href="https://modrinth.com/mod/create-tfmg"><picture><source srcset="https://img.shields.io/badge/Modrinth-202830?style=for-the-badge&logo=modrinth" media="(prefers-color-scheme: dark)"><img src="https://img.shields.io/badge/Modrinth-white?style=for-the-badge&logo=modrinth" alt="Modrinth"></picture></a>
  <a href="https://discord.gg/HCRF9PYdSy"><picture><source srcset="https://img.shields.io/badge/Discord-202830?style=for-the-badge&logo=discord" media="(prefers-color-scheme: dark)"><img src="https://img.shields.io/badge/Discord-white?style=for-the-badge&logo=discord" alt="Discord"></picture></a>
  <br>
  <a>Heavy Engineering & Oil For The Create Mod</a>
</div>

<br>

## Info

Create is by default a steam/clockpunk mod and most addons aim to expand this part of Create and do that pretty well,
we thought the next natural expansion would be moving on from steampunk to dieselpunk.
We believe that create could be later used not just as a single steampunk tech mod,
but due to its modularity and polishedness, it is a perfect base for other tech mods aiming to Create (get it) something new with it,
essentially using it as a library.
We wanna be the first ones to try and prove this concept.

<br>

## Features

* Large Distilleries
* Realistic Electricity
* Steel Mills
* Concrete
* Electrolyzers
* Steel
* Aluminum
* Cast Iron
* Lead
* Sulfur
* OIL!!!
* Quad Potato Cannon
* Flamethrowers
* And more..

<br>

![refinery image](https://cdn.modrinth.com/data/USgVjXsk/images/16f8c83fbec919fdc571236d62434b2d8050cf11.png)

