<p align="center"><img src="https://i.imgur.com/r0ZlRwr.png"></p>

**Tough As Nails** is a **Minecraft mod** that adds various features to increase the game's difficulty, including body temperature and thirst.

© 2026 Glitchfiend. All rights reserved.
