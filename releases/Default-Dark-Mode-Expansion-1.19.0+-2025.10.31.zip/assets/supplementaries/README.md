# Supplementaries

Supplementaries is a highly configurable Forge mod focused on adding valuable content which fills the gaps vanilla has. Its features are tailored to be functional, aesthetically viable, and complementary to preexisting content and provide many new ways to enhance your Vanilla+ experience.

Before reporting any issues be sure to check out the wiki!


## Cloning this repo?

In case you want to compile the mod for yourself be warned that you might have to changesome of the import lines in the 3 build.gradle files (common, fabric, neoforge) to include dependencies from cursemaven or modrinth maven, noteably for moonlight lib as the mod is usually configured to fetch that jar from a local mavenlocal folder
