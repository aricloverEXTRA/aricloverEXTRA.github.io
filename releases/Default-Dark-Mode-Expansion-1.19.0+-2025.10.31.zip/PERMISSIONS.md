## Distribution Permissions

The Default Dark Mode: Expansion resource pack is ONLY officially published on:
- CurseForge
- Modrinth
- Planet Minecraft

Any other sites—such as 9Minecraft, Gamerunner, and similar—are NOT authorized to redistribute any part of this pack.

Only the **code** is MIT licensed. The **assets** are ALL RIGHTS RESERVED. See LICENSE_ASSETS.txt for details.
